import React, { useState } from "react";
import styled from "styled-components";
import Login from "./Login";
import Signup from "./Signup";
import Main from "./Main";

const Layout = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #f5f5f5;
`;

function App() {
  const [page, setPage] = useState("login");

  return (
    <Layout>
      {page === "login" && <Login setPage={setPage} />}
      {page === "signup" && <Signup setPage={setPage} />}
      {page === "main" && <Main setPage={setPage} />}
    </Layout>
  );
}

export default App;
