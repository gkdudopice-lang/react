import React, { useState } from "react";
import styled from "styled-components";

const Container = styled.div`
  width: 500px;
  margin: 0 auto;
  padding: 40px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  box-sizing: border-box;
  text-align: center;
`;

const Title = styled.h2`
  margin-bottom: 24px;
  color: #333;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 16px;
`;

const Input = styled.input`
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 14px;
`;

const Button = styled.button`
  padding: 12px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  cursor: pointer;
  &:hover {
    background-color: #0056b3;
  }
`;

const SecondaryButton = styled(Button)`
  background-color: #6c757d;
  margin-top: 10px;
  width: 100%;
  &:hover {
    background-color: #5a6268;
  }
`;

const ToggleText = styled.p`
  margin-top: 20px;
  font-size: 14px;
  color: #666;
  span {
    color: #007bff;
    cursor: pointer;
    font-weight: bold;
    text-decoration: underline;
    margin-left: 5px;
  }
`;

const Login = ({ setPage }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();

    if (!email.trim() || !password.trim()) {
      return;
    }

    setPage("main");
  };

  return (
    <Container>
      <Title>Log In</Title>
      <Form onSubmit={handleLogin}>
        <Input
          type="email"
          placeholder="Email Address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <Input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <Button type="submit">Log in</Button>
      </Form>

      <SecondaryButton type="button" onClick={() => {}}>
        Get started
      </SecondaryButton>

      <ToggleText>
        계정이 없으신가요?
        <span onClick={() => setPage("signup")}>Sign up</span>
      </ToggleText>
    </Container>
  );
};

export default Login;
