import React from "react";
import styled, { keyframes } from "styled-components";

const fadeIn = keyframes`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
`;

const Container = styled.div`
  width: 500px;
  margin: 0 auto;
  padding: 40px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  box-sizing: border-box;
  text-align: center;
`;

const WelcomeMessage = styled.h1`
  animation: ${fadeIn} 3s ease-in-out forwards;
  color: #28a745;
  font-size: 28px;
  margin-bottom: 20px;
`;

const Button = styled.button`
  padding: 10px 20px;
  background-color: #dc3545;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  cursor: pointer;
  margin-top: 20px;
  &:hover {
    background-color: #c82333;
  }
`;

const Main = ({ setPage }) => {
  return (
    <Container>
      <WelcomeMessage>Welcome!</WelcomeMessage>
      <p style={{ color: "#666" }}>성공적으로 접속되었습니다.</p>
      <Button onClick={() => setPage("login")}>Log Out</Button>
    </Container>
  );
};

export default Main;
