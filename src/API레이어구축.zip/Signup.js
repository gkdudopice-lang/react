import React from "react";
import styled from "styled-components";

const Container = styled.div`
  width: 500px;
  margin: 0 auto;
  padding: 40px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  box-sizing: border-box;
  text-align: center;
`;

const Title = styled.h2`
  margin-bottom: 24px;
  color: #333;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 16px;
`;

const Input = styled.input`
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 14px;
`;

const Button = styled.button`
  padding: 12px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  cursor: pointer;
  &:hover {
    background-color: #0056b3;
  }
`;

const ToggleText = styled.p`
  margin-top: 20px;
  font-size: 14px;
  color: #666;
  span {
    color: #007bff;
    cursor: pointer;
    font-weight: bold;
    text-decoration: underline;
    margin-left: 5px;
  }
`;

const Signup = ({ setPage }) => {
  const handleSignupSubmit = (e) => {
    e.preventDefault();

    alert("가입완료");
    setPage("login");
  };

  return (
    <Container>
      <Title>Sign Up</Title>

      <Form onSubmit={handleSignupSubmit}>
        <Input type="email" placeholder="Email Address" required />
        <Input type="password" placeholder="Password" required />
        <Button type="submit">Sign Up</Button>
      </Form>

      <ToggleText>
        이미 계정이 있으신가요?
        <span onClick={() => setPage("login")}>Log in</span>
      </ToggleText>
    </Container>
  );
};

export default Signup;
